package com.cg.appl.services;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

public interface TraineeServices {

	 Trainee getTraineeDetails(int traineeId)throws TraineeException;
}

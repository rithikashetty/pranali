package com.cg.appl.daos;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

public interface TraineeDao {
	
	 Trainee getTraineeDetails(int traineeId)throws TraineeException;

}

package com.cg.appl.daos;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

@Repository("traineeDao")
public class TarineeDaoImpl implements TraineeDao {

	private EntityManagerFactory factory;

	
	@Resource(name="entityMFactory")
	public void setEntityMFactory(EntityManagerFactory factory){
		this.factory=factory;
		
	}
	
	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {//service is calling
		EntityManager manager=factory.createEntityManager();
		Trainee trainee = manager.find(Trainee.class, traineeId);
		
		return trainee;
	}

}

package com.cg.appl.service;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.dao.TraineeDao;
import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

@Service("traineeService")
public class TraineeServiceImpl implements TraineeService {

	private TraineeDao dao;
	
	@Resource(name="traineeDao")
	public void setTraineeDao(TraineeDao dao){
		this.dao= dao;
	}
	
	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
		
		return dao.getTraineeDetails(traineeId);
	}

	@Override
	public List<Trainee> getAllTrainees() throws TraineeException {
	
		return dao.getAllTrainees();
	}
	
	//(Container Managed Transactions) manages database transactions eg; begin, commit
	
	@Transactional     
	@Override
	public Trainee addTrainee(Trainee trainee) throws TraineeException {
		
		return dao.addTrainee(trainee);
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.updateTrainee(trainee);
	}

	@Override
	public boolean deleteTrainee(int traineeId) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.deleteTrainee(traineeId);
	}

}

package com.cg.appl.controllers;

import java.util.ArrayList;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
import com.cg.appl.service.TraineeService;

@Controller
public class TraineeCrudController {

	private TraineeService services;
	private List<String> domainList;
	private List<String> locations;
	
	
	@PostConstruct
	public void initialize(){
		domainList= new ArrayList<>();
		domainList.add("Java");
		domainList.add(".NET");
		domainList.add("Testing");
		domainList.add("BI");
		domainList.add("Analytics");
		domainList.add("Database");
		
		locations= new ArrayList<>();
		locations.add("Mumbai");
		locations.add("Pune");
		locations.add("Kolkata");
		locations.add("Bangalore");
		locations.add("Delhi");
		
		

	}
	
	@Resource(name="traineeService")
	public void setTraineeService(TraineeService services){
		this.services= services;
	}
	
	@RequestMapping("login")
	public ModelAndView loginCheck(@RequestParam("logName") String name, @RequestParam("logPswd") String paswd){
	
		ModelAndView model= null;
		if(name.equals("admin") && paswd.equals("admin")){
		model= new ModelAndView("welcome");
		
		}
		
		else{
			model= new ModelAndView("login");
			model.addObject("msg", "Invalid Credentials");
		}
		return model;
	}
	
	@RequestMapping("welcome")
	public ModelAndView getWelcomePage(){
		ModelAndView model= new ModelAndView("welcome");
		return model;
		
	}
	
	
	@RequestMapping("enterTraineeNo")
	public ModelAndView enterTraineeNo(){
		ModelAndView model= new ModelAndView("enterTraineeNo");
		return model;
		
	}
	
	@RequestMapping("getTraineeDetails")
	public ModelAndView getTraineeDetails(@RequestParam("traineeNo") int traineeNo){
		
		System.out.println("ID: "+traineeNo);
		ModelAndView model= null;
		try {
			Trainee trainee= services.getTraineeDetails(traineeNo);
			
			 model= new ModelAndView("traineeDetails");
			model.addObject("traineeData", trainee);
			
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		return model;
	}	
		
	@RequestMapping("listAllTrainees")
	public ModelAndView getAllTrainees(){
		
		ModelAndView model= null;
		try {
			List<Trainee> traineeList= services.getAllTrainees();
			 model= new ModelAndView("listAllTrainees");
				model.addObject("allTraineeData", traineeList);
				
		} 
		catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		return model;
	}
		
	@RequestMapping("addTrainee")  //entryForm.do
	public ModelAndView addTrainee(){
		ModelAndView model= new ModelAndView("getTraineeDetails");
		
		model.addObject("trainee", new Trainee());
		model.addObject("domains", domainList);
		model.addObject("locations", locations);
		return model;
		
	}
	
	@RequestMapping("addTraineeData")   //submitEntryForm.do
	public ModelAndView addTraineeData(@ModelAttribute @Valid Trainee trainee, BindingResult result){
		
		//ModelAndView model= new ModelAndView();
		ModelAndView model= null;
		if(result.hasErrors()){
			
			
			model= new ModelAndView();	
			model.addObject("trainee", new Trainee());
			model.addObject("domains", domainList);
			model.addObject("locations", locations);
			model.setViewName("getTraineeDetails");
				
			return model;
		}
		try {
			Trainee traineeResponse = services.addTrainee(trainee);

			 model= new ModelAndView("successInsert");
			//model.setViewName("successInsert");
			model.addObject("trainee", traineeResponse);
			
			
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			//model.setViewName("error");
			model.addObject("errMsg", "Record insertion failde"+e.getMessage());
		}
		return model;
		
		
	}
	
	
	@RequestMapping("updateTrainee")
	public ModelAndView updateTrainee(@RequestParam("id") int traineeNo){
		
		System.out.println("In updateTrainee ID: "+traineeNo);
		ModelAndView model= null;
		try {
			Trainee trainee= services.getTraineeDetails(traineeNo);
			System.out.println("In updateTrainee "+trainee);
			
			 model= new ModelAndView("updateTraineeDetails");
				model.addObject("traineeData", trainee);
				//model.addObject("trainee", new Trainee());
				model.addObject("domains", domainList);
				model.addObject("locations", locations);
				//return model;
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", "error while getting form"+e.getMessage());
		}
		
			
		
		return model;
	}	
	
	@RequestMapping("updateTraineeData")
	public ModelAndView updateTraineeData(@ModelAttribute Trainee trainee){
		ModelAndView model= null;
		
		try {
			System.out.println(trainee);
			Trainee traineeNew= services.updateTrainee(trainee);
			System.out.println(traineeNew);
			model= new ModelAndView("updateSuccess");
			model.addObject(traineeNew);
			
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		
		return model;
	}
	
	@RequestMapping("deleteTrainee")
	/*public ModelAndView deleteTrainee(@RequestParam("id") int traineeNo){
		ModelAndView model= null;
		System.out.println("ID: "+traineeNo);
		return model;
	}*/
	
	public ModelAndView deleteTrainee(){
		ModelAndView model= new ModelAndView("deleteTraineePage");
		
		return model;
	}
	
	@RequestMapping("deleteTraineeRecord")
	public ModelAndView deleteTraineeRecord(@RequestParam("t_id") int traineeNo){
		System.out.println("Delete ID: "+traineeNo);
		ModelAndView model= null;
		try {
			//boolean flag= services.deleteTrainee(traineeNo);
			Trainee trainee= services.getTraineeDetails(traineeNo);
			model= new ModelAndView("deleteTraineePage");
			
			model.addObject("traineeData", trainee);
			
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		return model;
	}
	
	
	@RequestMapping("deleteConfirm")
	public ModelAndView deleteConfirm(@RequestParam("id") int traineeNo){
		ModelAndView model= null;
		System.out.println("In deleteConfirm: "+traineeNo);
		try {
			boolean flag= services.deleteTrainee(traineeNo);
			if(flag== true){
			model= new ModelAndView("deleteTraineePage");
			
			model.addObject("deleteMsg", "Delete Successful");
			}
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		return model;
	}
	
}

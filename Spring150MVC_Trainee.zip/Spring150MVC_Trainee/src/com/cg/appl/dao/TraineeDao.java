package com.cg.appl.dao;

import java.util.List;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

public interface TraineeDao {

	Trainee getTraineeDetails(int traineeId) throws TraineeException;
	List<Trainee> getAllTrainees() throws TraineeException;
	Trainee addTrainee(Trainee trainee) throws TraineeException;
	Trainee updateTrainee(Trainee trainee) throws TraineeException;
	boolean deleteTrainee(int traineeId) throws TraineeException;
}
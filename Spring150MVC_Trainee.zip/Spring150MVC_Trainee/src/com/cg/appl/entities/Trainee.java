package com.cg.appl.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;



@Entity(name="trainee")
@Table(name="TRAINEE")
@SequenceGenerator(name="trainee_generate", sequenceName="TRAINEE_SEQ", allocationSize=1, initialValue=1008)
public class Trainee {

	private int traineeID;
	private String traineeName;
	private String traineeDomain;
	private String traineeLocation;
	private String email;
	
	public Trainee(int traineeID, String traineeName, String traineeDomain,
			String traineeLocation) {
		super();
		this.traineeID = traineeID;
		this.traineeName = traineeName;
		this.traineeDomain = traineeDomain;
		this.traineeLocation = traineeLocation;
	}

	public Trainee() {
		super();
	}

	@Id
	@Column(name="TRAINEEID")
	@GeneratedValue(generator="trainee_generate", strategy=GenerationType.SEQUENCE)
	public int getTraineeID() {
		return traineeID;
	}

	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}

	@NotEmpty(message="Name cannot be empty")
	@NotNull(message="Name is required")
	@Size(min=1, max=10, message="Name must be of size 1 to 10")
	@Column(name="TRAINEENAME")
	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	@Column(name="TRAINEEDOMAIN")
	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	@Column(name="TRAINEELOCATION")
	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	
	@Transient
	@Email(message="Invalid email address")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Trainee [traineeID=" + traineeID + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}
	
	
	
}
